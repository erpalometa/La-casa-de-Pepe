import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import re


#Pepe Márquez Romero 1M-B
# 17/03/2021

#Para ejecutar el script deberas tener instalado seaborn, matplotlib y pandas
# Puedes instalar estos paquetes con el comando pip install paquete

#con write.csv(dataframe , "nombre_archivo.csv") con este comando en R 
# en este caso hice write.csv(pelis1998.1 , "pelis1998.csv")
# genero un archivo csv que leo con read_csv  


#Paso los datos del csv a un dataframe 
df = pd.read_csv("pelis1998.csv")
#Creo la columna budget2 
df["budget2"]= df["budget"]/1000000
budget2=df["budget2"]
#variables para referirme a las columnas 
rating= df.get("rating")
length= df.get("length")
budget= df["budget"]
#imprimo el dataframe
 # print(df)
#df.info()

# Funcion tabla de Frecuencias 
def Tabla_Frecuencias_g(variable , intervalos_string):
    intervalo_numero=[int(s) for s in re.findall(r'-?\d+\.?\d*', intervalos_string[0])]
    interval= [(((df[(df[variable] >= intervalo_numero[0]) & (df[variable] <= intervalo_numero[1])]).count())[variable])]
    intervalos= pd.DataFrame(interval,columns=['Frecuency'] )
    intervalos =intervalos.rename(index={0:intervalos_string[0]})
    for inter in intervalos_string:
        intervalo_numero= [int(s) for s in re.findall(r'-?\d+\.?\d*', inter)]
        intervalos.loc[inter] = (df[(df[variable] > intervalo_numero[0]) & (df[variable] <= intervalo_numero[1])]).count()[variable]
    tabla = intervalos
    tabla["Frec C"]= tabla['Frecuency'].cumsum()
    tabla["Rel"]= tabla['Frecuency'] / tabla['Frec C'].values[-1]
    tabla["Rel C"]= tabla['Rel'].cumsum()
    return tabla

# Funcion para poligonos de frecuencias 
def poligon(serie):
    i=1
    aux= serie.iloc[0]
    aux2=0
    serie.iloc[0]=0
    while(i<serie.count()):
        aux2=serie.iloc[i]
        serie.iloc[i]=aux
        aux=aux2
        i+=1
    serie.iloc[-1]=1
    return serie


# Tabla de Frecuencias de Budget2
print(Tabla_Frecuencias_g("budget2" ,["(0,20]","(20,40]","(40,60]","(60,80]","(80,100]","(100,120]","(120,140]"]))

print("\n\n")

#Poligono de Frecuencias acumuladas 
pol=Tabla_Frecuencias_g("budget2" ,["(0,20]","(20,40]","(40,60]","(60,80]","(80,100]","(100,120]","(120,140]"])['Rel C']
pol=poligon(pol)
plt.plot(pol,marker='.')
plt.show()

#Lista de variables e intervalo para budget2
lista=['length','budget','rating']
intervalo = [0,20,40,60,80,100,120,140]
#Imprimo los máximos de cada categoría 
#df["rating"].idxmax() devuelve el indice del mayor valor de rating 
#df['title'].values[index] devuelve el título de la película con mayor valor 

print( "Máximo de valoración es "+ str(df["title"].values[df["rating"].idxmax()]) + " y es "+ str(df["rating"].max()))
#print( "La valoracion de "+str(df["title"].values[df["budget"].idxmax()]) + " es "+ str(df["rating"].values[df["budget"].idxmax()]))
print( "Máximo de presupuesto es "+str(df["title"].values[df["budget2"].idxmax()])+" y es "+ str(df["budget2"].max()) + "€")
print( "Máximo de duración es "+str(df["title"].values[df["length"].idxmax()])+" y es "+ str(df["length"].max())+" min"+"\n\n")

#Imprimo los mínimos de cada categoría
print( "Mínimo de valoración es "+ str(df["title"].values[df["rating"].idxmin()]) + " y es "+ str(df["rating"].min()))
print( "Mínimo de presupuesto es "+ str(df["title"].values[df["budget2"].idxmin()]) + " y es "+ str(df["budget2"].min())+"€")
print( "Mínimo de valoración es "+ str(df["title"].values[df["length"].idxmin()]) + " y es "+ str(df["length"].min())+" min"+"\n\n")


#Funcion summary
def summary(variable):
    resumen = df.agg({variable:["min", "max","mean"]})
    resumen.loc["Q1"]=[ budget2.quantile(q=0.25)]
    resumen.loc["Q2"]=[ budget2.quantile(q=0.5)]
    resumen.loc["Q3"]=[ budget2.quantile(q=0.75)]
    print(resumen)

#Resumen de Budget2 
summary("budget2")


#Boxplot de budget
plt.boxplot(budget2 , meanline=True ,showmeans=True,vert=False)
plt.xlabel("Presupuesto en € y en escala 10^8 ")
plt.show()

#Histograma budget
plt.hist(budget ,color='red', rwidth=0.7 ) #bins=bin_edges
plt.title('Histograma del presupuesto')
plt.xlabel('Presupuesto en € ')
plt.ylabel('Número de películas')
plt.show()


#Histograma rating
plt.hist(rating ,color='green', rwidth=0.7)
plt.title('Histograma de la valoración')
plt.xlabel('Rating 1-8')
plt.ylabel('Número de películas')
plt.show()

print("\n\n")
#Matriz de correlaciones 

corr = df.corr(method="pearson")
print(corr)

#Matriz de diagramas de dispersion
g = sns.PairGrid(df , vars=lista)
g.map_offdiag(sns.regplot,color='black') 
plt.text(-2,13,"Correlacion lineal entre\n budget y rating \n\n"+str(corr["budget"].values[3]),ha="center") #corr budget rating
plt.text(-9,20,"Correlacion lineal entre\n budget y length \n\n"+str(corr["budget"].values[1]),ha="center") #corr budget length
plt.text(6,5,"Correlacion lineal entre\n length y rating \n\n"+str(corr["length"].values[3]),ha="center") #corr budget rating
plt.show()

df["budget2"]= df["budget"]/1000000
budget2=df["budget2"]

# Desviacion tipica
print("Desviacion tipica de budget "+str(budget.std()))
print("Desviacion tipica de budget2 "+str(budget2.std()))

# Varianza 
print("Varianza de budget "+str(budget.var()))
print("Varianza de budget2 "+str(budget2.var())+"\n\n")

def stem_leaf(d):
    #Genera un simple diagramas de tallos y hojas
    l,t=np.sort(d),10
    O=range(int(l[0]-l[0]%t),int(l[-1]+11),t)
    I=np.searchsorted(l,O)
    for e,a,f in zip(I,I[1:],O): 
        print('%3d|'%(f/t),*(l[e:a]-f),sep='')
        
stem_leaf(budget2)






